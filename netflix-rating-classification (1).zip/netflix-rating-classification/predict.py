"""Predict the audience category for a few example titles using the saved model.

Usage:  python predict.py
"""
import pandas as pd

from src.inference import make_title_row, predict_rows

if __name__ == "__main__":
    examples = pd.concat([
        make_title_row("Movie", "Animated Family Adventure", 88, ["United States"],
                       ["Children & Family Movies", "Comedies"], 2020, 2021, False),
        make_title_row("TV Show", "Dark Crime Thriller", 2, ["United Kingdom"],
                       ["Crime TV Shows", "TV Dramas", "TV Thrillers"], 2021, 2021, False),
        make_title_row("Movie", "Teen Romantic Comedy", 102, ["United States"],
                       ["Comedies", "Romantic Movies"], 2019, 2020, True),
    ], ignore_index=True)
    print(predict_rows(examples).to_string(index=False))
