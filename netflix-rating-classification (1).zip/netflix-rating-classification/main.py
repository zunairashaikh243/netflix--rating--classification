"""Run the full pipeline:  python main.py

Step 1  Analyze rating categories      -> images/01-05
Step 2  Prepare training datasets      -> stratified 80/20 split
Step 3  Train classification models    -> 5-fold CV on 5 models
Step 4  Optimize model performance     -> GridSearch (tree) + RandomizedSearch (forest)
Step 5  Evaluate prediction accuracy   -> reports/ + images/06-11
"""
import json

import joblib
import pandas as pd

from src import config as C
from src import eda, evaluate, train
from src.data_preprocessing import load_raw, prepare_data


def main() -> None:
    C.MODELS_DIR.mkdir(exist_ok=True); C.REPORTS_DIR.mkdir(exist_ok=True)

    print("STEP 1 - Analyzing rating categories")
    X_tr, X_te, y_tr, y_te, df, X = prepare_data()
    eda.run_eda(load_raw(), df)

    print(f"\nSTEP 2 - Prepared data: {X.shape[0]} titles, {X.shape[1]} features")
    print(f"  train={len(X_tr)}  test={len(X_te)}")

    print("\nSTEP 3 - Cross-validating baseline models")
    cv_table = train.cross_validate_baselines(X_tr, y_tr)

    print("\nSTEP 4 - Hyperparameter tuning")
    dt_search = train.tune_decision_tree(X_tr, y_tr)
    print(f"  Decision Tree best CV macro-F1 = {dt_search.best_score_:.3f}  {dt_search.best_params_}")
    rf_search = train.tune_random_forest(X_tr, y_tr)
    print(f"  Random Forest best CV macro-F1 = {rf_search.best_score_:.3f}  {rf_search.best_params_}")

    print("\nSTEP 5 - Evaluating on the held-out test set")
    fitted = {name: m.fit(X_tr, y_tr) for name, m in train.baseline_models().items()}
    tuned = {"Decision Tree (tuned)": dt_search.best_estimator_, "Random Forest (tuned)": rf_search.best_estimator_}
    all_models = {**fitted, **tuned}

    results = pd.DataFrame({name: evaluate.score_model(m, X_te, y_te) for name, m in all_models.items()}).T
    results.index.name = "model"; results = results.reset_index()
    print(results.round(3).to_string(index=False))

    evaluate.plot_model_comparison(results)
    evaluate.plot_per_class_f1({k: all_models[k] for k in
                                ["Majority Baseline", "Logistic Regression", "Decision Tree (tuned)", "Random Forest (tuned)"]}, X_te, y_te)
    best_name = results.loc[results["f1_macro"].idxmax(), "model"]
    best = all_models[best_name]
    evaluate.plot_confusion(best, X_te, y_te, f"Confusion Matrix: {best_name}", "12_confusion_matrix_best.png")
    evaluate.plot_confusion(tuned["Decision Tree (tuned)"], X_te, y_te, "Confusion Matrix: Decision Tree (tuned)", "13_confusion_matrix_tree.png")
    imp = evaluate.plot_feature_importance(tuned["Random Forest (tuned)"], X.columns)
    evaluate.plot_tuning_effect(pd.DataFrame({
        "before": [results.set_index("model").loc["Decision Tree", "f1_macro"], results.set_index("model").loc["Random Forest", "f1_macro"]],
        "after": [results.set_index("model").loc["Decision Tree (tuned)", "f1_macro"], results.set_index("model").loc["Random Forest (tuned)", "f1_macro"]],
    }, index=["Decision Tree", "Random Forest"]))
    evaluate.plot_learning_curve(tuned["Random Forest (tuned)"], X_tr, y_tr)
    evaluate.plot_tree_depth_curve(X_tr, y_tr, X_te, y_te)

    # Save artefacts
    results.round(4).to_csv(C.REPORTS_DIR / "model_comparison.csv", index=False)
    cv_table.round(4).to_csv(C.REPORTS_DIR / "cross_validation.csv", index=False)
    imp.head(20).round(4).to_csv(C.REPORTS_DIR / "feature_importance.csv", header=["importance"])
    (C.REPORTS_DIR / "classification_report.txt").write_text(
        f"Best model: {best_name}\n\n" + evaluate.report_text(best, X_te, y_te))
    (C.REPORTS_DIR / "best_params.json").write_text(json.dumps({
        "decision_tree": dt_search.best_params_, "random_forest": rf_search.best_params_}, indent=2, default=str))
    joblib.dump({"model": best, "features": list(X.columns), "classes": C.CATEGORY_ORDER},
                C.MODELS_DIR / "best_model.joblib", compress=3)

    print(f"\nBest model: {best_name}")
    print(evaluate.report_text(best, X_te, y_te))


if __name__ == "__main__":
    main()
