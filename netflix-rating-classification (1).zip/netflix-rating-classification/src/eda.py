"""Step 1: analyze rating categories and save presentation-ready charts."""
from __future__ import annotations

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

from . import config as C
from .plot_style import apply_theme, save


def plot_raw_ratings(df_raw: pd.DataFrame) -> None:
    apply_theme()
    counts = df_raw["rating"].value_counts()
    colors = [C.CATEGORY_COLORS.get(C.RATING_TO_CATEGORY.get(r), C.GREY) for r in counts.index]
    fig, ax = plt.subplots(figsize=(11, 5))
    bars = ax.bar(counts.index, counts.values, color=colors)
    ax.bar_label(bars, padding=3, color=C.LIGHT, fontsize=9)
    ax.set_title("Raw Netflix Ratings (colored by audience category)")
    ax.set_ylabel("Number of titles")
    ax.grid(axis="x", visible=False)
    handles = [plt.Rectangle((0, 0), 1, 1, color=c) for c in C.CATEGORY_COLORS.values()] + [plt.Rectangle((0, 0), 1, 1, color=C.GREY)]
    ax.legend(handles, list(C.CATEGORY_COLORS) + ["Unrated (dropped)"], title="Category")
    save(fig, "01_raw_ratings.png")


def plot_class_balance(df: pd.DataFrame) -> None:
    apply_theme()
    counts = df["audience"].value_counts().reindex(C.CATEGORY_ORDER)
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    cols = [C.CATEGORY_COLORS[c] for c in counts.index]
    bars = axes[0].bar(counts.index, counts.values, color=cols)
    axes[0].bar_label(bars, padding=3, color=C.LIGHT)
    axes[0].set_title("Audience Category Counts")
    axes[0].grid(axis="x", visible=False)
    axes[1].pie(counts.values, labels=counts.index, colors=cols, autopct="%1.1f%%", startangle=90,
                wedgeprops=dict(width=0.45, edgecolor=C.DARK), textprops={"color": C.LIGHT})
    axes[1].set_title("Class Share")
    save(fig, "02_class_balance.png")


def plot_type_vs_category(df: pd.DataFrame) -> None:
    apply_theme()
    ct = pd.crosstab(df["type"], df["audience"], normalize="index")[C.CATEGORY_ORDER] * 100
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ct.plot(kind="barh", stacked=True, ax=ax, color=[C.CATEGORY_COLORS[c] for c in ct.columns], edgecolor=C.DARK)
    for cont in ax.containers:
        ax.bar_label(cont, fmt="%.0f%%", label_type="center", color="black", fontsize=9)
    ax.set_title("Audience Category by Content Type")
    ax.set_xlabel("Share of titles (%)")
    ax.set_ylabel("")
    ax.grid(visible=False)
    ax.legend(ncol=4, loc="upper center", bbox_to_anchor=(0.5, -0.15))
    save(fig, "03_type_vs_category.png")


def plot_genre_heatmap(df: pd.DataFrame) -> None:
    apply_theme()
    g = df.assign(genre=df["listed_in"].str.split(r",\s*")).explode("genre").reset_index(drop=True)
    top = g["genre"].value_counts().head(15).index
    g = g[g["genre"].isin(top)]
    ct = pd.crosstab(g["genre"], g["audience"], normalize="index")[C.CATEGORY_ORDER] * 100
    ct = ct.sort_values("Adults", ascending=False)
    fig, ax = plt.subplots(figsize=(9, 7))
    sns.heatmap(ct, annot=True, fmt=".0f", cmap=sns.light_palette(C.RED, as_cmap=True), ax=ax,
                cbar_kws={"label": "% of genre"}, linewidths=1, linecolor=C.DARK, annot_kws={"color": "black"})
    ax.set_title("Genre vs Audience Category (row %)")
    ax.set_ylabel("")
    ax.grid(False)
    save(fig, "04_genre_heatmap.png")


def plot_numeric_distributions(df: pd.DataFrame) -> None:
    apply_theme()
    movies = df[df["type"] == "Movie"].copy()
    movies["minutes"] = movies["duration"].str.extract(r"(\d+)")[0].astype(float)
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    for cat in C.CATEGORY_ORDER:
        sns.kdeplot(movies.loc[movies["audience"] == cat, "minutes"], ax=axes[0], label=cat,
                    color=C.CATEGORY_COLORS[cat], fill=True, alpha=0.25, linewidth=2)
        sns.kdeplot(df.loc[df["audience"] == cat, "release_year"], ax=axes[1], label=cat,
                    color=C.CATEGORY_COLORS[cat], fill=True, alpha=0.25, linewidth=2, bw_adjust=1.5)
    axes[0].set_title("Movie Runtime by Category"); axes[0].set_xlabel("Minutes"); axes[0].set_xlim(30, 200)
    axes[1].set_title("Release Year by Category"); axes[1].set_xlabel("Release year"); axes[1].set_xlim(1990, 2022)
    axes[0].legend(); axes[1].legend()
    save(fig, "05_numeric_distributions.png")


def run_eda(df_raw: pd.DataFrame, df: pd.DataFrame) -> None:
    plot_raw_ratings(df_raw)
    plot_class_balance(df)
    plot_type_vs_category(df)
    plot_genre_heatmap(df)
    plot_numeric_distributions(df)
