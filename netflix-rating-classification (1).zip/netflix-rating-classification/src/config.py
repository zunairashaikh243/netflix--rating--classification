"""Central configuration: paths, random seed, rating groups and plot theme."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "Dataset.csv"
IMAGES_DIR = ROOT / "images"
MODELS_DIR = ROOT / "models"
REPORTS_DIR = ROOT / "reports"

RANDOM_STATE = 42
TEST_SIZE = 0.20
CV_FOLDS = 5

# Raw Netflix rating -> audience category (ordered from youngest to oldest audience)
RATING_TO_CATEGORY = {
    "TV-Y": "Kids", "TV-Y7": "Kids", "TV-Y7-FV": "Kids", "TV-G": "Kids", "G": "Kids",
    "TV-PG": "Family", "PG": "Family",
    "TV-14": "Teens", "PG-13": "Teens",
    "TV-MA": "Adults", "R": "Adults", "NC-17": "Adults",
}
# "NR" and "UR" mean not rated, so they carry no audience information and are dropped.
CATEGORY_ORDER = ["Kids", "Family", "Teens", "Adults"]

TOP_COUNTRIES = 12
TOP_GENRES = 30

# Netflix-inspired theme
RED = "#E50914"
DARK = "#141414"
PANEL = "#1f1f1f"
LIGHT = "#F5F5F1"
GREY = "#8c8c8c"
CATEGORY_COLORS = {"Kids": "#46d369", "Family": "#f5c518", "Teens": "#2d9cdb", "Adults": "#E50914"}
