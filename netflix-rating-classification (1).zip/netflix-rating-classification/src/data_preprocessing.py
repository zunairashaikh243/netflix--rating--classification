"""Steps 1-2: load the data, group rating labels, engineer features, split."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from . import config as C


def load_raw(path=C.DATA_PATH) -> pd.DataFrame:
    return pd.read_csv(path)


def add_target(df: pd.DataFrame) -> pd.DataFrame:
    """Map the 14 raw ratings to 4 audience categories and drop unrated titles."""
    df = df.copy()
    df["audience"] = df["rating"].map(C.RATING_TO_CATEGORY)
    return df.dropna(subset=["audience"]).reset_index(drop=True)


def _parse_duration(s: pd.Series) -> pd.DataFrame:
    num = s.str.extract(r"(\d+)")[0].astype(float)
    is_season = s.str.contains("Season", na=False)
    return pd.DataFrame({
        "duration_min": np.where(is_season, 0, num),   # movies: minutes
        "n_seasons": np.where(is_season, num, 0),      # TV shows: seasons
    })


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """Turn raw columns into a numeric feature matrix (no target leakage)."""
    out = pd.DataFrame(index=df.index)
    out["is_movie"] = (df["type"] == "Movie").astype(int)
    out = out.join(_parse_duration(df["duration"]))
    out["release_year"] = df["release_year"]

    added = pd.to_datetime(df["date_added"].str.strip(), format="%m/%d/%Y", errors="coerce")
    out["year_added"] = added.dt.year.fillna(added.dt.year.median())
    out["month_added"] = added.dt.month.fillna(added.dt.month.median())
    out["years_to_netflix"] = (out["year_added"] - out["release_year"]).clip(lower=0)

    out["has_director"] = (df["director"].str.strip() != "Not Given").astype(int)
    out["n_directors"] = np.where(out["has_director"] == 1, df["director"].str.count(",") + 1, 0)

    countries = df["country"].fillna("Unknown").str.split(r",\s*")
    out["n_countries"] = countries.str.len()
    top_c = pd.Series([c for lst in countries for c in lst]).value_counts().head(C.TOP_COUNTRIES).index
    for c in top_c:
        out[f"country_{c}"] = countries.apply(lambda lst, c=c: int(c in lst))

    genres = df["listed_in"].str.split(r",\s*")
    out["n_genres"] = genres.str.len()
    top_g = pd.Series([g for lst in genres for g in lst]).value_counts().head(C.TOP_GENRES).index
    for g in top_g:
        out[f"genre_{g}"] = genres.apply(lambda lst, g=g: int(g in lst))
    return out


def prepare_data():
    """Return X_train, X_test, y_train, y_test, full cleaned frame, feature frame."""
    df = add_target(load_raw())
    X = engineer_features(df)
    y = df["audience"]
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=C.TEST_SIZE, stratify=y, random_state=C.RANDOM_STATE
    )
    return X_tr, X_te, y_tr, y_te, df, X
