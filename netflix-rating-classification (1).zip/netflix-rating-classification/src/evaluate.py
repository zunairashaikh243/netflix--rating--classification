"""Step 5: metrics, confusion matrices, comparison charts and feature importance."""
from __future__ import annotations

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, classification_report,
                             confusion_matrix, f1_score, precision_score, recall_score)
from sklearn.model_selection import learning_curve

from . import config as C
from .plot_style import apply_theme, save
from .train import CV


def score_model(model, X_te, y_te) -> dict:
    pred = model.predict(X_te)
    return {
        "accuracy": accuracy_score(y_te, pred),
        "balanced_accuracy": balanced_accuracy_score(y_te, pred),
        "precision_macro": precision_score(y_te, pred, average="macro", zero_division=0),
        "recall_macro": recall_score(y_te, pred, average="macro", zero_division=0),
        "f1_macro": f1_score(y_te, pred, average="macro"),
        "f1_weighted": f1_score(y_te, pred, average="weighted"),
    }


def report_text(model, X_te, y_te) -> str:
    return classification_report(y_te, model.predict(X_te), labels=C.CATEGORY_ORDER, digits=3)


def plot_confusion(model, X_te, y_te, title: str, fname: str) -> None:
    apply_theme()
    pred = model.predict(X_te)
    cm = confusion_matrix(y_te, pred, labels=C.CATEGORY_ORDER)
    cm_pct = cm / cm.sum(axis=1, keepdims=True) * 100
    annot = np.array([[f"{n}\n({p:.0f}%)" for n, p in zip(rn, rp)] for rn, rp in zip(cm, cm_pct)])
    fig, ax = plt.subplots(figsize=(7, 6))
    sns.heatmap(cm_pct, annot=annot, fmt="", cmap=sns.light_palette(C.RED, as_cmap=True), cbar=False,
                xticklabels=C.CATEGORY_ORDER, yticklabels=C.CATEGORY_ORDER, ax=ax,
                linewidths=2, linecolor=C.DARK, annot_kws={"color": "black", "fontsize": 11})
    ax.set_title(title); ax.set_xlabel("Predicted"); ax.set_ylabel("Actual"); ax.grid(False)
    save(fig, fname)


def plot_model_comparison(results: pd.DataFrame) -> None:
    apply_theme()
    res = results.sort_values("f1_macro")
    fig, ax = plt.subplots(figsize=(11, 5.5))
    y = np.arange(len(res)); h = 0.38
    b1 = ax.barh(y - h / 2, res["accuracy"], h, color=C.RED, label="Accuracy")
    b2 = ax.barh(y + h / 2, res["f1_macro"], h, color="#2d9cdb", label="Macro F1")
    ax.bar_label(b1, fmt="%.3f", padding=3, color=C.LIGHT, fontsize=9)
    ax.bar_label(b2, fmt="%.3f", padding=3, color=C.LIGHT, fontsize=9)
    ax.set_yticks(y); ax.set_yticklabels(res["model"]); ax.set_xlim(0, 1)
    ax.set_title("Model Comparison on Held-out Test Set"); ax.grid(axis="y", visible=False)
    ax.legend(loc="lower right")
    save(fig, "06_model_comparison.png")


def plot_per_class_f1(models: dict, X_te, y_te) -> None:
    apply_theme()
    data = {}
    for name, m in models.items():
        f = f1_score(y_te, m.predict(X_te), labels=C.CATEGORY_ORDER, average=None)
        data[name] = f
    df = pd.DataFrame(data, index=C.CATEGORY_ORDER)
    fig, ax = plt.subplots(figsize=(10, 5.5))
    palette = [C.GREY, "#2d9cdb", C.RED, "#f5c518", "#46d369"]
    df.plot(kind="bar", ax=ax, color=palette[:len(df.columns)], edgecolor=C.DARK, width=0.8)
    ax.set_title("Per-class F1 Score"); ax.set_ylabel("F1"); ax.set_ylim(0, 1); ax.tick_params(axis="x", rotation=0)
    ax.grid(axis="x", visible=False); ax.legend(ncol=3, fontsize=8)
    save(fig, "07_per_class_f1.png")


def plot_feature_importance(rf, feature_names, top: int = 15) -> pd.DataFrame:
    apply_theme()
    imp = pd.Series(rf.feature_importances_, index=feature_names).sort_values(ascending=False)
    fig, ax = plt.subplots(figsize=(9, 6.5))
    top_imp = imp.head(top).iloc[::-1]
    ax.barh(top_imp.index, top_imp.values, color=C.RED)
    ax.set_title(f"Top {top} Features (Tuned Random Forest)"); ax.set_xlabel("Importance")
    ax.grid(axis="y", visible=False)
    save(fig, "08_feature_importance.png")
    return imp


def plot_tuning_effect(before_after: pd.DataFrame) -> None:
    apply_theme()
    fig, ax = plt.subplots(figsize=(8.5, 5))
    x = np.arange(len(before_after)); w = 0.38
    b1 = ax.bar(x - w / 2, before_after["before"], w, color=C.GREY, label="Default")
    b2 = ax.bar(x + w / 2, before_after["after"], w, color=C.RED, label="Tuned")
    ax.bar_label(b1, fmt="%.3f", padding=3, color=C.LIGHT); ax.bar_label(b2, fmt="%.3f", padding=3, color=C.LIGHT)
    ax.set_xticks(x); ax.set_xticklabels(before_after.index)
    ax.set_ylim(0, max(before_after.max()) + 0.12); ax.set_ylabel("Test macro F1")
    ax.set_title("Effect of Hyperparameter Tuning"); ax.grid(axis="x", visible=False); ax.legend()
    save(fig, "09_tuning_effect.png")


def plot_learning_curve(model, X, y) -> None:
    apply_theme()
    sizes, tr, va = learning_curve(model, X, y, cv=CV, scoring="accuracy", n_jobs=-1,
                                   train_sizes=np.linspace(0.15, 1.0, 7), random_state=C.RANDOM_STATE)
    fig, ax = plt.subplots(figsize=(8.5, 5))
    for arr, col, lab in [(tr, "#46d369", "Training"), (va, C.RED, "Cross-validation")]:
        ax.plot(sizes, arr.mean(1), "o-", color=col, label=lab, linewidth=2)
        ax.fill_between(sizes, arr.mean(1) - arr.std(1), arr.mean(1) + arr.std(1), color=col, alpha=0.15)
    ax.set_title("Learning Curve (Tuned Random Forest)"); ax.set_xlabel("Training samples"); ax.set_ylabel("Accuracy")
    ax.legend()
    save(fig, "10_learning_curve.png")


def plot_tree_depth_curve(X_tr, y_tr, X_te, y_te) -> None:
    from sklearn.tree import DecisionTreeClassifier
    apply_theme()
    depths = list(range(1, 21))
    tr, te = [], []
    for d in depths:
        m = DecisionTreeClassifier(max_depth=d, min_samples_leaf=5, random_state=C.RANDOM_STATE).fit(X_tr, y_tr)
        tr.append(m.score(X_tr, y_tr)); te.append(m.score(X_te, y_te))
    fig, ax = plt.subplots(figsize=(8.5, 5))
    ax.plot(depths, tr, "o-", color="#46d369", label="Train", linewidth=2)
    ax.plot(depths, te, "o-", color=C.RED, label="Test", linewidth=2)
    best = int(np.argmax(te)) + 1
    ax.axvline(best, color=C.LIGHT, linestyle="--", alpha=0.6); ax.text(best + 0.3, min(te), f"best depth = {best}", color=C.LIGHT)
    ax.set_title("Decision Tree: Depth vs Accuracy (over-fitting check)"); ax.set_xlabel("max_depth"); ax.set_ylabel("Accuracy")
    ax.legend()
    save(fig, "11_tree_depth_curve.png")
