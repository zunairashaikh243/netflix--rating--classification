"""Netflix Audience Rating Classification package."""
