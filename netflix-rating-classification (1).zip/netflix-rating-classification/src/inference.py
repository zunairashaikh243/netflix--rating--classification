"""Load the saved model and predict the audience category for new titles."""
from __future__ import annotations

import joblib
import pandas as pd

from . import config as C
from .data_preprocessing import engineer_features, load_raw


def load_bundle():
    return joblib.load(C.MODELS_DIR / "best_model.joblib")


def available_options(bundle) -> dict:
    """Countries and genres the model knows about (taken from its feature names)."""
    feats = bundle["features"]
    return {
        "countries": sorted(f.removeprefix("country_") for f in feats if f.startswith("country_") and f != "country_Not Given"),
        "genres": sorted(f.removeprefix("genre_") for f in feats if f.startswith("genre_")),
    }


def make_title_row(content_type: str, title: str, duration_value: int, countries: list[str],
                   genres: list[str], release_year: int, year_added: int, has_director: bool) -> pd.DataFrame:
    """Build one raw-format row (same columns as Dataset.csv) from user inputs."""
    duration = f"{duration_value} min" if content_type == "Movie" else f"{duration_value} Season" + ("s" if duration_value != 1 else "")
    return pd.DataFrame([{
        "show_id": "new", "type": content_type, "title": title or "Untitled",
        "director": "Some Director" if has_director else "Not Given",
        "country": ", ".join(countries) if countries else "Not Given",
        "date_added": f"6/1/{year_added}", "release_year": release_year, "rating": "",
        "duration": duration, "listed_in": ", ".join(genres) if genres else "Dramas",
    }])


def predict_rows(rows: pd.DataFrame, bundle=None) -> pd.DataFrame:
    """Return predicted category and class probabilities for raw-format rows."""
    bundle = bundle or load_bundle()
    full = pd.concat([load_raw(), rows], ignore_index=True)
    X = engineer_features(full).tail(len(rows))[bundle["features"]]
    model = bundle["model"]
    proba = model.predict_proba(X)
    out = rows[["title"]].reset_index(drop=True)
    out["predicted_category"] = model.predict(X)
    for i, cls in enumerate(model.classes_):
        out[f"p_{cls}"] = proba[:, i].round(4)
    return out
