"""Steps 3-4: baseline models, then hyperparameter tuning of the tree models."""
from __future__ import annotations

import time

import pandas as pd
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV, StratifiedKFold, cross_validate
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

from . import config as C

CV = StratifiedKFold(n_splits=C.CV_FOLDS, shuffle=True, random_state=C.RANDOM_STATE)


def baseline_models() -> dict:
    rs = C.RANDOM_STATE
    return {
        "Majority Baseline": DummyClassifier(strategy="most_frequent"),
        "Logistic Regression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000, random_state=rs)),
        "Decision Tree": DecisionTreeClassifier(random_state=rs),
        "Random Forest": RandomForestClassifier(n_estimators=200, n_jobs=1, random_state=rs),
        "Gradient Boosting": GradientBoostingClassifier(n_estimators=100, random_state=rs),
    }


def cross_validate_baselines(X, y) -> pd.DataFrame:
    rows = []
    for name, model in baseline_models().items():
        t0 = time.time()
        cv = cross_validate(model, X, y, cv=CV, scoring=["accuracy", "f1_macro"], n_jobs=-1)
        acc, f1 = cv["test_accuracy"], cv["test_f1_macro"]
        rows.append({"model": name, "cv_accuracy": acc.mean(), "cv_accuracy_std": acc.std(),
                     "cv_f1_macro": f1.mean(), "seconds": time.time() - t0})
        print(f"  {name:<20} acc={acc.mean():.3f}  macro-F1={f1.mean():.3f}", flush=True)
    return pd.DataFrame(rows)


def tune_decision_tree(X, y) -> GridSearchCV:
    grid = {
        "max_depth": [3, 5, 7, 9, 12, 15, None],
        "min_samples_leaf": [1, 3, 5, 10, 20],
        "min_samples_split": [2, 10, 30],
        "criterion": ["gini", "entropy"],
        "class_weight": [None, "balanced"],
    }
    gs = GridSearchCV(DecisionTreeClassifier(random_state=C.RANDOM_STATE), grid, cv=CV,
                      scoring="f1_macro", n_jobs=-1, refit=True)
    return gs.fit(X, y)


def tune_random_forest(X, y, n_iter: int = 20) -> RandomizedSearchCV:
    dist = {
        "n_estimators": [150, 250, 350],
        "max_depth": [8, 12, 16, 20, None],
        "min_samples_leaf": [1, 2, 3, 5],
        "min_samples_split": [2, 5, 10],
        "max_features": ["sqrt", "log2", 0.3, 0.5],
        "class_weight": [None, "balanced", "balanced_subsample"],
    }
    rs = RandomizedSearchCV(RandomForestClassifier(n_jobs=1, random_state=C.RANDOM_STATE), dist,
                            n_iter=n_iter, cv=CV, scoring="f1_macro", n_jobs=-1,
                            random_state=C.RANDOM_STATE, refit=True)
    return rs.fit(X, y)
