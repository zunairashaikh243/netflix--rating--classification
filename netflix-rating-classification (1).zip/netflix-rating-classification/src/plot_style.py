"""Shared matplotlib theme so every figure looks consistent."""
import matplotlib.pyplot as plt

from . import config as C


def apply_theme() -> None:
    plt.rcParams.update({
        "figure.facecolor": C.DARK, "axes.facecolor": C.PANEL, "savefig.facecolor": C.DARK,
        "axes.edgecolor": "#3a3a3a", "axes.labelcolor": C.LIGHT, "axes.titlecolor": C.LIGHT,
        "axes.titleweight": "bold", "axes.titlesize": 14, "axes.labelsize": 11,
        "xtick.color": C.LIGHT, "ytick.color": C.LIGHT, "text.color": C.LIGHT,
        "grid.color": "#333333", "axes.grid": True, "grid.alpha": 0.6,
        "legend.facecolor": C.PANEL, "legend.edgecolor": "#3a3a3a",
        "font.family": "DejaVu Sans", "figure.dpi": 110, "savefig.dpi": 170,
    })


def save(fig, name: str) -> None:
    C.IMAGES_DIR.mkdir(exist_ok=True)
    fig.tight_layout()
    fig.savefig(C.IMAGES_DIR / name, bbox_inches="tight")
    plt.close(fig)
